// Mobile nav toggle
const toggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.nav');
if (toggle){
  toggle.addEventListener('click', () => {
    nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
  });
}

// Countdown to Dec 26, 2025 18:00 Africa/Lagos (WAT)
(function(){
  const el = document.getElementById('countdown');
  if(!el) return;
  function pad(n){return String(n).padStart(2,'0')}
  function render(){
    // Target date in local time
    const target = new Date('2025-12-26T18:00:00+01:00');
    const now = new Date();
    let diff = target - now;
    if (diff < 0) diff = 0;
    const s = Math.floor(diff/1000);
    const days = Math.floor(s/86400);
    const hrs = Math.floor((s%86400)/3600);
    const mins = Math.floor((s%3600)/60);
    const secs = s%60;
    el.innerHTML = [
      ['Days', days],
      ['Hours', pad(hrs)],
      ['Minutes', pad(mins)],
      ['Seconds', pad(secs)]
    ].map(([lbl, num]) => '<div class="unit"><span class="num">'+num+'</span><span class="lbl">'+lbl+'</span></div>').join('');
  }
  render();
  setInterval(render, 1000);
})();
